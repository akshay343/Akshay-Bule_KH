import java.util.*;

class Ex14
{
  public static void main(String args[])
  {
   int year;
   Scanner get=new Scanner(System.in);
   System.out.println("Enter year "); 
   year=get.nextInt();
   
   if((year%4==0) && (year%100 !=0) || (year%400 ==0))
   {
    System.out.println("Leap Year");
   }
   else 
  {
   System.out.println("Not a Leap year");
  }
  }
}