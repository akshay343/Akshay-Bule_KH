import java.util.Scanner;
/*
class Ex11
{
  public static void main(String args[])
  {
    int a,b;
    Scanner in=new Scanner(System.in);
    System.out.println("Enter the value of a : ");
    a=in.nextInt();
    System.out.println("Enter the value of b : ");
    b=in.nextInt();
    a=a+b;
    b=a-b;
    a=a-b;
    System.out.println("After swapping  : ");
    System.out.println("a = "+a+" b = "+b);
  }
}
*/
class Ex11
{
  public static void main(String args[])
  {
    int a,b;
    Scanner in=new Scanner(System.in);
    System.out.println("Enter the value of a : ");
    a=in.nextInt();
    System.out.println("Enter the value of b : ");
    b=in.nextInt();
    a=a*b;
    b=a/b;
    a=a/b;
    System.out.println("After swapping  : ");
    System.out.println("a = "+a+" b = "+b);
  }
}


