/*
import java.util.Scanner;
public class Ex9 
{
    public static void main(String args[])
    {
        int m, year, week, day;
        Scanner s = new Scanner(System.in);
        System.out.print("Enter the number of days:");
        m = s.nextInt();
        year = m / 365;
        m = m % 365;
        System.out.println("No. of years:"+m);
        System.out.println("No. of years:"+year);
        week = m / 7;
        m = m % 7;
        System.out.println("No. of weeks:"+week);
        day = m;
        System.out.println("No. of days:"+day);
    }
}*/

public class Ex9 {

	public static void main(String args[]) {

		int days = 670;
                int years=days/365;
		int day = days % 30;
		int month = days / 30;
		System.out.println(days + " days = " + years +" Years "+ month + " Month and " + day + " days");
	}
}