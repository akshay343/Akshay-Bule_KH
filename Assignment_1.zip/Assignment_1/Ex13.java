import java.util.Scanner;
/*class Ex13
{
 public static void main(String args[])
 {
  int large,a=110,b=90,c=240;
  if((a>b) && (a>c))
  {
   large=a;
  }
  else if((b>a) && (b>c))
  {
   large=b;
  }
  else
 {
  large=c;
 } 
 System.out.println("Greatest number :"+large);

 }
}
*/

class Ex13
{
 public static void main(String args[])
 { 
   int large,a=310,b=400,c=240;
   large=((a>b) && (a>c))?a:((b>a) && (b>c))?b:c;
   System.out.println("Greatest number :"+large);

 }
}

