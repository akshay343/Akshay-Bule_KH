/*
class Ex5
{
 public static void main(String args[])
 {
  String str=args[0];
  System.out.println("Welcome "+str);
  //System.out.println("Welcome "+args[0]);

 }

}
*/


class Ex5
{
  public static void main(String args[])
  {
    for(int i=0;i<args.length;i++)
    {
       System.out.println(args[i]);
    }
  }
}