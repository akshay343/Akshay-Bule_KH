import java.util.*;

class Ex7
{
  public static void main(String args[])
  {
   int s1,s2,s3,s4,s5,sum;
   float avg;
   Scanner scan=new Scanner(System.in);
   System.out.println("Enter the marks of five subjects");
   s1=scan.nextInt();
   s2=scan.nextInt();
   s3=scan.nextInt();
   s4=scan.nextInt();
   s5=scan.nextInt();

   sum=s1+s2+s3+s4+s5;
   avg=(float)(sum/5.0);
   System.out.println("percentage marks = "+avg); 
  }
}