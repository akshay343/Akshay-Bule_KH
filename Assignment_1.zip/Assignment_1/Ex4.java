
import java.util.*;

class Ex4
{
  public static void main(String args[])
  {
    byte a=125,b=100;
    int sum = a+b;
    System.out.println(sum);    
  }
}