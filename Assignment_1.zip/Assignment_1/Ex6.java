import java.util.Scanner;

class Ex6
{
  public static void main(String args[])
  {
    float r,a,c;
    float pi=3.14f;  
    Scanner obj=new Scanner(System.in);
    System.out.println("Enter radius of circle : ");
    r=obj.nextFloat();
    a=pi*r*r;
    c=2*pi*r;
    System.out.println("Area of circle = "+a);
    System.out.println("Circumference of circle = "+c);
    obj.close();
  }

}