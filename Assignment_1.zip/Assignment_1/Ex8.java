import java.util.*;

class Ex8
{
  public static void main(String args[])
  {
    long p;
    double i;
    float n,r;
    Scanner in=new Scanner(System.in);
    System.out.println("Enter principle amount : ");
    p=in.nextLong();
    System.out.println("Enter duration in years : ");
    n=in.nextFloat();
    System.out.println("Enter rate of interest : ");
    r=in.nextFloat();

    i=(p*n*r)/100;
    System.out.println("Total interest : "+i);
   
  }
}