import java.util.*;


class Ex15
{
  public static void main(String args[])
  {
    char g;
    int a;
    Scanner scan=new Scanner(System.in);
    System.out.println("Enter your gender :\n 'm' for male and 'f' for female");
    g=scan.next().charAt(0);
    
    System.out.println("Enter your age : ");
    a=scan.nextInt();
    System.out.println(g);
    System.out.println(a);

    if(g=='m')
    {
     if(a>=21)
     {
      System.out.println("You are eligible for marriage : ");
     }
     else 
      System.out.println("You are not eligible for marriage : ");
    }
    else if(g=='f')
    {
     if(a>=18)
     {
      System.out.println("You are eligible for marriage : ");
     }
     else 
      System.out.println("You are not eligible for marriage : ");
    }
    
  }
}