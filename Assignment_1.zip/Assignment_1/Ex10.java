import java.util.*;

class Ex10
{
  public static void main(String args[])
  {
     float fah,deg;
     Scanner scan=new Scanner(System.in);
     System.out.println("Enter temperature in fahrenheit : ");
     fah=scan.nextFloat();
     deg=(fah-32)*5/9;
     System.out.println("Temperature in Degree celcius : "+deg);
  }

}