/*A. y = x2 + 3x - 7 (print value of y) 
B. y = x++ + ++x (print value of x and y) 
C. z = x++ - --y - --x  +  x++ (print value of x ,y and z)
D. z = x && y || !(x || y)  (print value of z) [ x, y, z are boolean variables ]
*/
import java.util.*;

class Ex3
{
  public static void main(String args[])
{

  int x=2,y,z=0;
  y=(x*2) + (3*x) - 7;
  System.out.println("Y = "+y);
  y= x++ + ++x;
  System.out.println("Y = "+y+" and X = "+x);
  z=x++ - --y - --x + x++;
  System.out.println("Y = "+y+" and X = "+x+" and z = "+z);
  boolean x=0,y=0,z=0;
  z = x && y || !(x || y);
  System.out.println("Z = "+z);
  

}

}