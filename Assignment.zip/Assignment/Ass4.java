class Ass4
{
  public static void main(String sargs[])
  {
    int a,b,c,d;
    a=-5+8*6;
    b=(55+9)%9;
    c=20+ -3*5/8;
    d=5+15/3*2-8%3;
    System.out.println(a);
    System.out.println(b);
    System.out.println(c);
    System.out.println(d);
  }
}






