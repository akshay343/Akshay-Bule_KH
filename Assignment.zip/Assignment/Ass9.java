class Ass9
{
    public static void main(String sargs[])
   {
     double val=((25.5 * 3.5 - 3.5 * 3.5) / (40.5 - 4.5));
     System.out.println(val);    

   }


}