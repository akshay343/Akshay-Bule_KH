import java.util.Scanner;

class Ass7
{
  public static void main(String sargs[])
  {
    Scanner in=new Scanner(System.in);
    System.out.println("Enter a number :");
    int num=in.nextInt();
    int i;
    for(i=1;i<=10;i++)
     {
       System.out.println(num*i);
     }
  }


}