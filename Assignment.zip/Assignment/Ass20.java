import java.util.*;


class Ass20
{
	public static void main(String...args)
	{
	 int num;   
	 Scanner sc=new Scanner(System.in);
         System.out.println("Enter a decimal number : ");
         num=sc.nextInt();
         String str=Integer.toHexString(num);
	 System.out.println("Hexa binary number : "+str);
   
        }

}

