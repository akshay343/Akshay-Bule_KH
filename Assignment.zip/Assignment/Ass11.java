import java.util.Scanner;

class Ass11
{
  	public static void main(String[] args)
	{

          float r;
          double pi=3.14,a,p;
          Scanner input=new Scanner(System.in);
          System.out.println("Enter radius of circle : ");
          r=input.nextFloat();
          a=pi*r*r;
          p=2*pi*r;
          System.out.println("Area of Circle : "+a);
          System.out.println("Perimeter of circle : "+p);
	}

}