class Ass2
{
   public static void main(String sargs[])
   {
       int sum,num1=74,num2=36;
       sum=num1+num2;
       System.out.println(sum);     
    
   }


}