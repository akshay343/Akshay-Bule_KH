import java.util.*;

class Ass13
{	
	public static void main(String []args)
	{ 
          
          float l,w;
          double a,p;
          Scanner sc=new Scanner(System.in);
          System.out.println("Enter lenght of rectangle : ");
          l=sc.nextFloat();
          System.out.println("Enter widht of rectangle : ");
          w=sc.nextFloat();
          a=l*w;
          p=2*(l+w);
          System.out.println("Area of rectangle : "+a);
          System.out.println("Perimeter of rectangle : "+p);   
          
	 
        
	}


}