class Ass3
{
  public static void main(String sargs[])
    {
     int div;
     div=50/3;    
     System.out.println(div);
      
    }

}