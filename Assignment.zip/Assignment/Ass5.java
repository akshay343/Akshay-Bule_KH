import java.util.Scanner;

class Ass5
{
  public static void main(String sargs[])
  {
    Scanner input=new Scanner(System.in);
    System.out.println("Enter a number : ");
    int num1=input.nextInt();
    System.out.println("Enter second number : ");
    int num2=input.nextInt();
    int product=num1*num2;
    System.out.println("The product is : "+product); 
 
  }

}