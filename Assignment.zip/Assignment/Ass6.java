import java.util.Scanner;

class Ass6
{
  public static void main(String sargs[])
  {
    Scanner scan=new Scanner(System.in);
    System.out.println("Enter a number : ");
    int num1=scan.nextInt();
    System.out.println("Enter second number : ");
    int num2=scan.nextInt();
    int add=num1+num2;
    int sub=num1-num2;
    int mult=num1*num2;
    int div=num1/num2;
    int mod=num1%num2;
    System.out.println(add); 
    System.out.println(sub);
    System.out.println(mult);
    System.out.println(div);
    System.out.println(mod);
 
  }

}