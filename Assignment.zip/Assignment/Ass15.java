import java.util.*;


/*class Ass15
{
	public static void main(String...args)
	{
            int a,b,c;
            Scanner in=new Scanner(System.in);
            System.out.println("Enter first number : ");
            a=in.nextInt();
            System.out.println("Enter second number : ");
            b=in.nextInt();
            c=a;
            a=b;
            b=c;
            System.out.println("After swapping a="+a);
            System.out.println("After swapping b="+b);
          }

}
*/



class swap
{
	public static void main(String...args)
	{
            int a,b,c;
            Scanner in=new Scanner(System.in);
            System.out.println("Enter first number : ");
            a=in.nextInt();
            System.out.println("Enter second number : ");
            b=in.nextInt();
            c=a+b;
            a=c-a;
            b=c-a;;
            System.out.println("After swapping a="+a);
            System.out.println("After swapping b="+b);
          }

}




