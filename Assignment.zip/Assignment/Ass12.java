import java.util.Scanner;

class Ass12
{
  public static void main(String[] args)
{
  int a,b,c,sum;
  double avj;
  Scanner input=new Scanner(System.in);
  System.out.println("Enter a number : ");
  a=input.nextInt();
  System.out.println("Enter a number : ");
  b=input.nextInt();
  System.out.println("Enter a number : ");
  c=input.nextInt();
  sum=a+b+c;
  avj=sum/3.0;
  System.out.println("Average : "+avj);
}
}