import java.util.*;


class Ass21
{
	public static void main(String...args)
	{
	 int num;   
	 Scanner sc=new Scanner(System.in);
         System.out.println("Enter a decimal number : ");
         num=sc.nextInt();
	 System.out.println(Integer.toOctalString(num));
   
        }

}

