class Ass8
{
	public static void main(String[] args)
	{
	 System.out.println("   J    a   V     V  a");
	 System.out.println("   J   a a   V   V  a a");
	 System.out.println("J  J  aaaaa   V V  aaaaa");
	 System.out.println(" JJ  a     a   V  a     a");
	}


}
