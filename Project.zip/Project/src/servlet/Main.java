package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserDao;
import dao.UserDaoImpl;
import pojo.User;




@WebServlet("/admin")
public class Main extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	   
	    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String task = request.getParameter("task");
		
		
		
		
		

		if(task.equals("select")) {
			
			
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			
			UserDao userDao = new UserDaoImpl();
			try {
				 
				
				List<User> userList = userDao.selectUser();
				
				
				for(User user1 : userList)
				{
					out.print("<br>");
					out.print("<h2> Id : "+  user1.getId() +"<h2>");
					out.print("<h3> Nme : "+  user1.getName() +"<h3>");
					out.print("<h3> City : "+  user1.getCity() +"<h3>");
					out.print("<h3> Mobile  : "+ user1.getMobile() +"<h3>");
					out.print("<br>");
					out.print("<button type=\"submit\" value=\"select\" name=\"task\"> Select </button>"); 
					 out.print("<hr>");
				}
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			out.print("<hr>");
			
			
			out.print("</h4>  <a href='logout'> Logout   </a> </h4>");
		}
//=========================================================================================================
		
		if(task.equals("delete")) {
			String userid = request.getParameter("id");
			int id = Integer.parseInt(userid);
			
			UserDaoImpl st = new UserDaoImpl();
			try {
				if( st.deleteUser(id))
				{
					response.setContentType("text/html");
					PrintWriter out = response.getWriter();
					out.print("<h2 align='center'> User deleted successfully  </h2> </br></br><hr>");
					
					out.print("</h4>  <a href='read.jsp'> Display Updated List </a> </h4></br>");
					out.print("</h3> <a href='Profile.jsp'>Go to Profile</a>  </h3></br>");
					out.print("</h4>  <a href='logout'> Logout   </a> </h4>");
				}
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			
			}
		
//-----------------------------------------------------------------------------------------
		 if(task.equals("update2")) {

			  String city = request.getParameter("city");
			  String pass = request.getParameter("pass");
			  
			  
			 
			  UserDao dao = new UserDaoImpl();
			  try {
				dao.updateUser2(pass,city);
				response.setContentType("text/html");
				PrintWriter out = response.getWriter();
				out.print("<h2 align='center' style='color:green'>  Your profile is  updated successfully  </h2> </br></br></br><hr>");
				
			 	out.print("</h3> <a href='userProfile.jsp' style='color:darkgreen'>Go to Profile</a>  </h3></br>");
				out.print("</h4>  <a href='logout' style='color:red'> Logout   </a> </h4>");
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		  }
			
			
	
		
		
		
//---------------------------------------------------------------------------------------------		
	  if(task.equals("update"))
	  {
		  String name = request.getParameter("name");
		  String user_id = request.getParameter("id");
		  int id = Integer.parseInt(user_id);
		  
		 
		  UserDao dao = new UserDaoImpl();
		  try {
			dao.updateUser(id,name);
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.print("<h2 align='center' style='color:green'>  User details has been updated successfully  </h2> </br></br><hr>");
			out.print("</h4>  <a href='read.sp' style='color:Yellow'> Display Updated List </a> </h4></br>");
		 	out.print("</h3> <a href='Profile.jsp' style='color:darkgreen'>Go to Profile</a>  </h3></br>");
			out.print("</h4>  <a href='logout' style='color:red'> Logout   </a> </h4>");
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	  }
		
		
	}
	

}
