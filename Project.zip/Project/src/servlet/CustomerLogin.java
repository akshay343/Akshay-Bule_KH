package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserDaoImpl;

/**
 * Servlet implementation class CustomerLogin
 */
@WebServlet("/customer")
public class CustomerLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final static String QUERY = "SELECT * FROM customer WHERE name = ? and password = ?";
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		 String name = request.getParameter("name");
		 String pass = request.getParameter("pass");
		 
		//Create DB connection
		Connection con = UserDaoImpl.getConnection();
		
		
		try {
			PreparedStatement pStmt = con.prepareStatement(QUERY);
			pStmt.setString(1, name);
			pStmt.setString(2, pass);
			
			ResultSet rSet = pStmt.executeQuery();
			
			if(rSet.next())
			{
			   	 Cookie cookie = new Cookie("name",name);
			     cookie.setMaxAge(90);
			   	 response.addCookie(cookie);
			   	 
			   	 response.setContentType("text/html");
			   	 PrintWriter out = response.getWriter();
			   	 
			   	 out.print(" <h2 align='center' style='color:darkgreen'> Login Successful </h2>\r\n"
			   	 		+ "          <h1 align='center'> Welcome </h1>");
			   	out.print("</h3> <a href='read.jsp' style='color:darkgreen'> Hire a driver </a>  </h3>");
			   	
			   	out.print("</h4>  <a href='logout' style='color:red'> Logout   </a> </h4>");
				
				 out.close();
				
				// response.sendRedirect("welcome.html");
			}else {
				response.sendRedirect("CustLogin.jsp?message=Invalid username or password");
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	
				

		
	}

}
