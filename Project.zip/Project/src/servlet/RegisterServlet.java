package servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserDao;
import dao.UserDaoImpl;
import pojo.User;



@WebServlet(name = "Register", urlPatterns = { "/register" })
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  
		 String name = request.getParameter("name");
	     String city = request.getParameter("city");
	     String mobile = request.getParameter("mobile");
	     String  password = request.getParameter("password");
	     //int fees = Integer.parseInt(studentFees);
	     
	     //1. Create Student Object
	     User user1 = new User(name,city,mobile,password);
	      
	     System.out.println(user1);
	     
	     
	     //work on jdbc starts from here
	     //DAO comprises of 3 things : 1. POJO class 2. Interface 3. Implementation class
	     UserDao studentDao = new UserDaoImpl();
	    try {
			if( studentDao.insertUser(user1))
			{
				response.sendRedirect("Login.jsp?message=Account created seccessfully");
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
	
			e.printStackTrace();
		}
	}

}
