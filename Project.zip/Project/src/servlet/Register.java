package servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserDao;
import dao.UserDaoImpl;
import pojo.Customer;
import pojo.User;


@WebServlet(name = "RegisterCustomer", urlPatterns = { "/register2" })
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		 String name = request.getParameter("name");
	     String email = request.getParameter("email");
	     String mobile = request.getParameter("mobile");
	     String  password = request.getParameter("password");
	     //int fees = Integer.parseInt(studentFees);
	     
	     //1. Create Student Object
	     Customer cust = new Customer(name,email,mobile,password);
	      
	     
	     
	     
	    
	     UserDao studentDao = new UserDaoImpl();
	    try {
			if( studentDao.insertCust(cust))
			{
				response.sendRedirect("CustLogin.jsp?message=Account created seccessfully");
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
	
			e.printStackTrace();
		}
	}

}
