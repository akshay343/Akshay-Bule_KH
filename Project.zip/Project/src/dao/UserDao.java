package dao;

import java.sql.SQLException;
import java.util.List;

import pojo.Customer;
import pojo.User;



public interface UserDao {

	public boolean insertUser(User user1) throws SQLException;
	public List<User> selectUser() throws SQLException;
	public boolean deleteUser(int id) throws SQLException;
	public int updateUser(int id,String name) throws SQLException;
	public int updateUser2(String pass,String city) throws SQLException;
	public boolean insertCust(Customer cust) throws SQLException;
}
