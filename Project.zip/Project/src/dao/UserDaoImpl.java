package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import pojo.Customer;
import pojo.User;

public class UserDaoImpl implements UserDao {

	    private final static String DRIVER = "com.mysql.cj.jdbc.Driver";
	    private final static String DB_URL = "jdbc:mysql://localhost:3306/driver_hiring";
	    private final static String DB_USER = "root";
	    private final static String DB_PASS = "cdac";
	    
	    private final static String QUERY = "INSERT INTO user (name,city,mobile,password) VALUES (?,?,?,?)";
	    private final static String INSERT = "INSERT INTO customer (name,email,mobile,password) VALUES (?,?,?,?)";
	    private final static String GET_ALL = "SELECT * FROM user";
	    private final static String DELETE_QUERY = "DELETE FROM user WHERE id=?";
	    private final static String UPDATE_QUERY = "UPDATE user SET name=?  WHERE id=?";
	    private final static String UPDATE = "UPDATE user SET city=?  WHERE password=?";
	    
	    public static  Connection getConnection() {
	    	Connection con = null;
	    	try {
			    Class.forName(DRIVER);
			    con = DriverManager.getConnection(DB_URL,DB_USER,DB_PASS);
			} catch (Exception e) {
				e.printStackTrace();
			}
	    	
	    	return con;
	    }
	    
//Insert	    
	@Override
	public boolean insertUser(User user1) throws SQLException {
		
	   Connection con = getConnection();
	   PreparedStatement pStmt = con.prepareStatement(QUERY);
	   
	    pStmt.setString(1, user1.getName());
	    pStmt.setString(2, user1.getCity());
	    pStmt.setString(3, user1.getMobile());
	    pStmt.setString(4, user1.getPassword());
	   
	    boolean flag = false;
	    if(pStmt.executeUpdate() > 0)
		   {
			   flag = true;
		   }
		
		return flag;
	}


	
	
//========================================================================================================================
	
//Select
	@Override
	public List<User> selectUser() throws SQLException {
		List<User> userList = new ArrayList<User>();
		
		Connection con = getConnection();
		Statement stmt = con.createStatement();
		ResultSet rSet = stmt.executeQuery(GET_ALL);
		
		while(rSet.next())
		{
			int id = rSet.getInt(1);
			String name = rSet.getString(2);
			String city = rSet.getString(3);
			String mobile = rSet.getString(4);
			String password = rSet.getString(5);
			
			userList.add(new User(id,name,city,mobile,password));
		}
		
		return userList;
	}
//===============================================================================================================

	@Override
	public boolean deleteUser(int id) throws SQLException {
		try  ( Connection con=getConnection();
				 PreparedStatement pStmt = con.prepareStatement(DELETE_QUERY);){
					
					 pStmt.setInt(1,id);   //Binding Statement 
					 if( pStmt.executeUpdate() > 0)
					 {
						 return true;
					 }
				  
				}
		return false;
	}
	
	
//====================================================================================================================

@Override
public int updateUser(int id,String name) throws SQLException {
	int n = 0;
	try(Connection con = getConnection();
			PreparedStatement pStmt = con.prepareStatement(UPDATE_QUERY);){
		
		
		pStmt.setString(1,name);
		pStmt.setInt(2,id);
		
		
		n = pStmt.executeUpdate();
		
	}
	
	return n;
}



//=========================================================================================================================

@Override
public int updateUser2(String pass, String city) throws SQLException {
	int n = 0;
	try(Connection con = getConnection();
			PreparedStatement pStmt = con.prepareStatement(UPDATE);){
		
		
		pStmt.setString(1,city);
		pStmt.setString(2,pass);
		
		
		n = pStmt.executeUpdate();
		
	}
	
	return n;
}

@Override
public boolean insertCust(Customer cust) throws SQLException {
	
	   Connection con = getConnection();
	   PreparedStatement pStmt = con.prepareStatement(INSERT);
	   
	    pStmt.setString(1, cust.getName());
	    pStmt.setString(2, cust.getEmail());
	    pStmt.setString(3, cust.getMobile());
	    pStmt.setString(4,cust.getPassword());
	   
	    boolean flag = false;
	    if(pStmt.executeUpdate() > 0)
		   {
			   flag = true;
		   }
		
		return flag;
}

	
}
